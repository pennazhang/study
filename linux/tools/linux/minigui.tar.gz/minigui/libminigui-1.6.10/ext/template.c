/*
** $Id: template.c 7366 2007-08-16 05:23:35Z xgwang $
** 
** XXX.c: <Description for this file>
** 
** Copyright (C) 2003-2007 Feynman Software.
**
** Create date: 2000/XX/XX by XXX XXXXXX.
**
** Current maintainer: 
*/

#include "template.h"

